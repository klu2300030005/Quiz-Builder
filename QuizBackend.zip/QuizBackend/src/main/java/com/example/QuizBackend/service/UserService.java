package com.example.QuizBackend.service;


import com.example.QuizBackend.model.User;
import com.example.QuizBackend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User register(User user) {
        // You can add email uniqueness check or password encryption here
        return userRepository.save(user);
    }

    public User login(String email, String password) {
        User user = userRepository.findByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        throw new RuntimeException("Invalid email or password");
    }

    public User getByEmail(String email) {
        return userRepository.findByEmail(email);
    }
}
