package com.example.QuizBackend.service;

import com.example.QuizBackend.model.Quiz;
import com.example.QuizBackend.repository.QuizRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuizService {

    @Autowired
    private QuizRepository quizRepository;

    public List<Quiz> getAllQuizzes() {
        return quizRepository.findAll();
    }

    public Quiz getQuizById(Long id) {
        return quizRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Quiz not found"));
    }

    public Quiz createQuiz(Quiz quiz) {
        quiz.getQuestions().forEach(q -> q.setQuiz(quiz));
        return quizRepository.save(quiz);
    }

    public List<Quiz> getQuizzesByUserId(Long userId) {
        return quizRepository.findByUserId(userId);
    }
}
