package com.example.QuizBackend.controller;

import com.example.QuizBackend.model.Quiz;
import com.example.QuizBackend.repository.QuizRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/quiz")
public class QuizController {

    @Autowired
    private QuizRepository quizRepository;

    @GetMapping
    public List<Quiz> getAll() {
        return quizRepository.findAll();
    }

    @PostMapping
    public Quiz create(@RequestBody Quiz quiz) {
        quiz.getQuestions().forEach(q -> q.setQuiz(quiz));
        return quizRepository.save(quiz);
    }

    @GetMapping("/{id}")
    public Quiz getById(@PathVariable Long id) {
        return quizRepository.findById(id).orElseThrow();
    }
}
