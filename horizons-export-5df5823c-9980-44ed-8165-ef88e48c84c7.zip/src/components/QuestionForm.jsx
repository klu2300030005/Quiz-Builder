
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Trash2, Plus, GripVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const QuestionForm = ({ question, index, onChange, onRemove }) => {
  const [selectedType, setSelectedType] = useState(question.type || 'multiple-choice');

  const handleTypeChange = (value) => {
    setSelectedType(value);
    onChange(index, { ...question, type: value });
  };

  const handleQuestionTextChange = (e) => {
    onChange(index, { ...question, text: e.target.value });
  };

  const handleOptionChange = (optionIndex, value) => {
    const updatedOptions = [...question.options];
    updatedOptions[optionIndex] = value;
    onChange(index, { ...question, options: updatedOptions });
  };

  const handleCorrectAnswerChange = (value) => {
    onChange(index, { ...question, correctAnswer: value });
  };

  const addOption = () => {
    const updatedOptions = [...(question.options || []), ''];
    onChange(index, { ...question, options: updatedOptions });
  };

  const removeOption = (optionIndex) => {
    const updatedOptions = question.options.filter((_, i) => i !== optionIndex);
    const updatedQuestion = { ...question, options: updatedOptions };
    
    // If the correct answer is the removed option, reset it
    if (question.correctAnswer === optionIndex.toString()) {
      updatedQuestion.correctAnswer = '';
    }
    
    onChange(index, updatedQuestion);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="mb-6"
    >
      <Card className="question-card">
        <CardHeader className="flex flex-row items-start justify-between pb-2">
          <div className="flex items-center gap-2">
            <GripVertical className="h-5 w-5 cursor-move text-muted-foreground" />
            <CardTitle className="text-lg">Question {index + 1}</CardTitle>
          </div>
          <Button 
            variant="destructive" 
            size="sm" 
            onClick={() => onRemove(index)}
            className="h-8 w-8 p-0"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor={`question-${index}`}>Question</Label>
            <Input
              id={`question-${index}`}
              value={question.text || ''}
              onChange={handleQuestionTextChange}
              placeholder="Enter your question"
              className="w-full"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor={`question-type-${index}`}>Question Type</Label>
            <Select 
              value={selectedType} 
              onValueChange={handleTypeChange}
            >
              <SelectTrigger id={`question-type-${index}`}>
                <SelectValue placeholder="Select question type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="multiple-choice">Multiple Choice</SelectItem>
                <SelectItem value="true-false">True/False</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {selectedType === 'multiple-choice' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Options</Label>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm" 
                  onClick={addOption}
                  className="h-8"
                >
                  <Plus className="mr-1 h-3.5 w-3.5" />
                  Add Option
                </Button>
              </div>
              
              {(question.options || []).map((option, optionIndex) => (
                <div key={optionIndex} className="flex items-center gap-2">
                  <Input
                    value={option}
                    onChange={(e) => handleOptionChange(optionIndex, e.target.value)}
                    placeholder={`Option ${optionIndex + 1}`}
                    className="flex-1"
                  />
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => removeOption(optionIndex)}
                    className="h-8 w-8 p-0"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              
              <div className="space-y-2">
                <Label>Correct Answer</Label>
                <RadioGroup
                  value={question.correctAnswer}
                  onValueChange={handleCorrectAnswerChange}
                  className="flex flex-col space-y-1"
                >
                  {(question.options || []).map((option, optionIndex) => (
                    <div key={optionIndex} className="flex items-center space-x-2">
                      <RadioGroupItem value={optionIndex.toString()} id={`option-${index}-${optionIndex}`} />
                      <Label htmlFor={`option-${index}-${optionIndex}`}>{option}</Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            </div>
          )}

          {selectedType === 'true-false' && (
            <div className="space-y-2">
              <Label>Correct Answer</Label>
              <RadioGroup
                value={question.correctAnswer}
                onValueChange={handleCorrectAnswerChange}
                className="flex flex-col space-y-1"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="true" id={`true-${index}`} />
                  <Label htmlFor={`true-${index}`}>True</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="false" id={`false-${index}`} />
                  <Label htmlFor={`false-${index}`}>False</Label>
                </div>
              </RadioGroup>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default QuestionForm;
