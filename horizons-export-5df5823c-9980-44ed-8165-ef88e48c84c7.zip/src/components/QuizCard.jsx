
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Edit, Play, Trash2, BarChart } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { formatDate } from '@/lib/utils';

const QuizCard = ({ quiz, onDelete }) => {
  const { id, title, description, questions, createdAt, attempts = [] } = quiz;
  
  const cardVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0, transition: { duration: 0.3 } },
    hover: { y: -5, boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)' }
  };

  return (
    <motion.div
      initial="initial"
      animate="animate"
      whileHover="hover"
      variants={cardVariants}
    >
      <Card className="quiz-card h-full overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="gradient-heading text-xl">{title}</CardTitle>
          <p className="text-xs text-muted-foreground">
            Created: {formatDate(createdAt)}
          </p>
        </CardHeader>
        <CardContent className="pb-3">
          <p className="line-clamp-2 text-sm text-muted-foreground">{description}</p>
          <div className="mt-4 flex items-center gap-2">
            <div className="rounded-full bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
              {questions.length} {questions.length === 1 ? 'Question' : 'Questions'}
            </div>
            {attempts.length > 0 && (
              <div className="rounded-full bg-secondary/80 px-2 py-1 text-xs font-medium">
                {attempts.length} {attempts.length === 1 ? 'Attempt' : 'Attempts'}
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between gap-2 pt-0">
          <div className="flex gap-2">
            <Button asChild size="sm" variant="outline">
              <Link to={`/edit/${id}`}>
                <Edit className="mr-1 h-3.5 w-3.5" />
                Edit
              </Link>
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button size="sm" variant="destructive">
                  <Trash2 className="mr-1 h-3.5 w-3.5" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the quiz
                    "{title}" and all of its data.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => onDelete(id)}>
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
          <Button asChild size="sm">
            <Link to={`/take/${id}`}>
              <Play className="mr-1 h-3.5 w-3.5" />
              Start Quiz
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default QuizCard;
