
import React, { createContext, useContext, useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useToast } from '@/components/ui/use-toast';

const QuizContext = createContext();

export const useQuiz = () => useContext(QuizContext);

export const QuizProvider = ({ children }) => {
  const [quizzes, setQuizzes] = useState([]);
  const { toast } = useToast();

  // Load quizzes from localStorage on initial render
  useEffect(() => {
    const savedQuizzes = localStorage.getItem('quizzes');
    if (savedQuizzes) {
      try {
        setQuizzes(JSON.parse(savedQuizzes));
      } catch (error) {
        console.error('Error parsing quizzes from localStorage:', error);
        toast({
          title: 'Error',
          description: 'Failed to load saved quizzes',
          variant: 'destructive',
        });
      }
    }
  }, []);

  // Save quizzes to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('quizzes', JSON.stringify(quizzes));
  }, [quizzes]);

  const createQuiz = (quizData) => {
    const newQuiz = {
      id: uuidv4(),
      createdAt: new Date().toISOString(),
      ...quizData,
    };
    
    setQuizzes((prevQuizzes) => [...prevQuizzes, newQuiz]);
    toast({
      title: 'Success',
      description: 'Quiz created successfully',
    });
    
    return newQuiz.id;
  };

  const updateQuiz = (id, quizData) => {
    setQuizzes((prevQuizzes) =>
      prevQuizzes.map((quiz) =>
        quiz.id === id
          ? { ...quiz, ...quizData, updatedAt: new Date().toISOString() }
          : quiz
      )
    );
    
    toast({
      title: 'Success',
      description: 'Quiz updated successfully',
    });
  };

  const deleteQuiz = (id) => {
    setQuizzes((prevQuizzes) => prevQuizzes.filter((quiz) => quiz.id !== id));
    
    toast({
      title: 'Success',
      description: 'Quiz deleted successfully',
    });
  };

  const getQuiz = (id) => {
    return quizzes.find((quiz) => quiz.id === id);
  };

  const saveQuizResults = (quizId, results) => {
    setQuizzes((prevQuizzes) =>
      prevQuizzes.map((quiz) => {
        if (quiz.id === quizId) {
          const attempts = quiz.attempts || [];
          return {
            ...quiz,
            attempts: [...attempts, { ...results, date: new Date().toISOString() }],
          };
        }
        return quiz;
      })
    );
    
    toast({
      title: 'Quiz Completed',
      description: `Your score: ${results.score}/${results.totalQuestions}`,
    });
  };

  return (
    <QuizContext.Provider
      value={{
        quizzes,
        createQuiz,
        updateQuiz,
        deleteQuiz,
        getQuiz,
        saveQuizResults,
      }}
    >
      {children}
    </QuizContext.Provider>
  );
};
