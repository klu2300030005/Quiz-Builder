
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { QuizProvider } from '@/contexts/QuizContext';
import { AuthProvider } from '@/contexts/AuthContext';
import ProtectedRoute from '@/components/ProtectedRoute';
import Dashboard from '@/pages/Dashboard';
import CreateQuiz from '@/pages/CreateQuiz';
import EditQuiz from '@/pages/EditQuiz';
import TakeQuiz from '@/pages/TakeQuiz';
import Login from '@/pages/Login';
import Layout from '@/components/Layout';

function App() {
  return (
    <AuthProvider>
      <QuizProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Layout>
                  <Dashboard />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/create"
            element={
              <ProtectedRoute>
                <Layout>
                  <CreateQuiz />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/edit/:id"
            element={
              <ProtectedRoute>
                <Layout>
                  <EditQuiz />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/take/:id"
            element={
              <ProtectedRoute>
                <Layout>
                  <TakeQuiz />
                </Layout>
              </ProtectedRoute>
            }
          />
        </Routes>
        <Toaster />
      </QuizProvider>
    </AuthProvider>
  );
}

export default App;
