
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, ArrowRight, Check, Home } from 'lucide-react';
import { useQuiz } from '@/contexts/QuizContext';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { calculateScore } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

const TakeQuiz = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { getQuiz, saveQuizResults } = useQuiz();
  const { toast } = useToast();
  const [quiz, setQuiz] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const quizData = getQuiz(id);
    if (quizData) {
      setQuiz(quizData);
      setAnswers(new Array(quizData.questions.length).fill(''));
    } else {
      toast({
        title: "Error",
        description: "Quiz not found",
        variant: "destructive",
      });
      navigate('/');
    }
    setLoading(false);
  }, [id, getQuiz, navigate, toast]);

  const handleAnswerChange = (value) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestionIndex] = value;
    setAnswers(newAnswers);
  };

  const goToNextQuestion = () => {
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      completeQuiz();
    }
  };

  const goToPreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const completeQuiz = () => {
    const calculatedResults = calculateScore(answers, quiz.questions);
    setResults(calculatedResults);
    setQuizCompleted(true);
    saveQuizResults(id, calculatedResults);
  };

  if (loading) {
    return (
      <div className="flex h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  if (quizCompleted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="mx-auto max-w-2xl space-y-8"
      >
        <Card className="overflow-hidden">
          <div className="animated-bg h-24"></div>
          <CardHeader className="pb-2">
            <CardTitle className="text-center text-2xl">Quiz Results</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-center">
            <div className="mx-auto my-6 flex h-32 w-32 items-center justify-center rounded-full bg-primary/10">
              <span className="text-4xl font-bold text-primary">{results.percentage}%</span>
            </div>
            
            <div className="space-y-2">
              <p className="text-lg font-medium">
                You scored {results.score} out of {results.totalQuestions}
              </p>
              <p className="text-muted-foreground">
                {results.percentage >= 80
                  ? 'Excellent work! You really know your stuff!'
                  : results.percentage >= 60
                  ? 'Good job! You have a solid understanding.'
                  : 'Keep practicing to improve your score!'}
              </p>
            </div>
            
            <div className="mt-8 grid grid-cols-2 gap-4">
              <Button variant="outline" onClick={() => navigate('/')}>
                <Home className="mr-2 h-4 w-4" />
                Back to Dashboard
              </Button>
              <Button onClick={() => {
                setQuizCompleted(false);
                setCurrentQuestionIndex(0);
                setAnswers(new Array(quiz.questions.length).fill(''));
              }}>
                <ArrowRight className="mr-2 h-4 w-4" />
                Take Again
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  const currentQuestion = quiz.questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / quiz.questions.length) * 100;

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={() => navigate('/')}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Exit Quiz
        </Button>
        <span className="text-sm font-medium">
          Question {currentQuestionIndex + 1} of {quiz.questions.length}
        </span>
      </div>

      <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
        <motion.div
          className="h-full bg-primary"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.3 }}
        />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestionIndex}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">{currentQuestion.text}</CardTitle>
            </CardHeader>
            <CardContent>
              {currentQuestion.type === 'multiple-choice' && (
                <RadioGroup
                  value={answers[currentQuestionIndex]}
                  onValueChange={handleAnswerChange}
                  className="space-y-3"
                >
                  {currentQuestion.options.map((option, index) => (
                    <div
                      key={index}
                      className="flex items-center space-x-2 rounded-lg border p-4 transition-colors hover:bg-accent"
                    >
                      <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                      <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                        {option}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              )}

              {currentQuestion.type === 'true-false' && (
                <RadioGroup
                  value={answers[currentQuestionIndex]}
                  onValueChange={handleAnswerChange}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-2 rounded-lg border p-4 transition-colors hover:bg-accent">
                    <RadioGroupItem value="true" id="true" />
                    <Label htmlFor="true" className="flex-1 cursor-pointer">
                      True
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-lg border p-4 transition-colors hover:bg-accent">
                    <RadioGroupItem value="false" id="false" />
                    <Label htmlFor="false" className="flex-1 cursor-pointer">
                      False
                    </Label>
                  </div>
                </RadioGroup>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button
                variant="outline"
                onClick={goToPreviousQuestion}
                disabled={currentQuestionIndex === 0}
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>
              <Button
                onClick={goToNextQuestion}
                disabled={!answers[currentQuestionIndex]}
              >
                {currentQuestionIndex === quiz.questions.length - 1 ? (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Finish
                  </>
                ) : (
                  <>
                    Next
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default TakeQuiz;
