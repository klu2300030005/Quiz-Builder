
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Plus, Save, ArrowLeft } from 'lucide-react';
import { useQuiz } from '@/contexts/QuizContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import QuestionForm from '@/components/QuestionForm';
import { useToast } from '@/components/ui/use-toast';

const EditQuiz = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { getQuiz, updateQuiz } = useQuiz();
  const { toast } = useToast();
  const [quizData, setQuizData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const quiz = getQuiz(id);
    if (quiz) {
      setQuizData(quiz);
    } else {
      toast({
        title: "Error",
        description: "Quiz not found",
        variant: "destructive",
      });
      navigate('/');
    }
    setLoading(false);
  }, [id, getQuiz, navigate, toast]);

  const handleTitleChange = (e) => {
    setQuizData({ ...quizData, title: e.target.value });
  };

  const handleDescriptionChange = (e) => {
    setQuizData({ ...quizData, description: e.target.value });
  };

  const handleQuestionChange = (index, updatedQuestion) => {
    const updatedQuestions = [...quizData.questions];
    updatedQuestions[index] = updatedQuestion;
    setQuizData({ ...quizData, questions: updatedQuestions });
  };

  const addQuestion = () => {
    setQuizData({
      ...quizData,
      questions: [
        ...quizData.questions,
        {
          text: '',
          type: 'multiple-choice',
          options: ['', ''],
          correctAnswer: ''
        }
      ]
    });
  };

  const removeQuestion = (index) => {
    if (quizData.questions.length === 1) {
      toast({
        title: "Cannot remove",
        description: "A quiz must have at least one question",
        variant: "destructive",
      });
      return;
    }
    
    const updatedQuestions = quizData.questions.filter((_, i) => i !== index);
    setQuizData({ ...quizData, questions: updatedQuestions });
  };

  const validateQuiz = () => {
    if (!quizData.title.trim()) {
      toast({
        title: "Validation Error",
        description: "Quiz title is required",
        variant: "destructive",
      });
      return false;
    }

    for (let i = 0; i < quizData.questions.length; i++) {
      const question = quizData.questions[i];
      
      if (!question.text.trim()) {
        toast({
          title: "Validation Error",
          description: `Question ${i + 1} text is required`,
          variant: "destructive",
        });
        return false;
      }

      if (question.type === 'multiple-choice') {
        if (!question.options || question.options.length < 2) {
          toast({
            title: "Validation Error",
            description: `Question ${i + 1} must have at least 2 options`,
            variant: "destructive",
          });
          return false;
        }

        const emptyOptions = question.options.some(option => !option.trim());
        if (emptyOptions) {
          toast({
            title: "Validation Error",
            description: `Question ${i + 1} has empty options`,
            variant: "destructive",
          });
          return false;
        }

        if (!question.correctAnswer && question.correctAnswer !== '0') {
          toast({
            title: "Validation Error",
            description: `Question ${i + 1} must have a correct answer selected`,
            variant: "destructive",
          });
          return false;
        }
      }

      if (question.type === 'true-false' && !question.correctAnswer) {
        toast({
          title: "Validation Error",
          description: `Question ${i + 1} must have a correct answer selected`,
          variant: "destructive",
        });
        return false;
      }
    }

    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateQuiz()) {
      return;
    }
    
    updateQuiz(id, quizData);
    navigate('/');
  };

  if (loading) {
    return (
      <div className="flex h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-3xl font-bold tracking-tight">Edit Quiz</h1>
        </div>
        <Button onClick={handleSubmit}>
          <Save className="mr-2 h-4 w-4" />
          Save Changes
        </Button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <div className="space-y-4 rounded-lg border p-6">
          <div className="space-y-2">
            <Label htmlFor="title">Quiz Title</Label>
            <Input
              id="title"
              value={quizData.title}
              onChange={handleTitleChange}
              placeholder="Enter quiz title"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={quizData.description}
              onChange={handleDescriptionChange}
              placeholder="Enter quiz description"
              rows={3}
            />
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Questions</h2>
            <Button onClick={addQuestion}>
              <Plus className="mr-2 h-4 w-4" />
              Add Question
            </Button>
          </div>

          {quizData.questions.map((question, index) => (
            <QuestionForm
              key={index}
              question={question}
              index={index}
              onChange={handleQuestionChange}
              onRemove={removeQuestion}
            />
          ))}
        </div>

        <div className="flex justify-end">
          <Button onClick={handleSubmit}>
            <Save className="mr-2 h-4 w-4" />
            Save Changes
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

export default EditQuiz;
